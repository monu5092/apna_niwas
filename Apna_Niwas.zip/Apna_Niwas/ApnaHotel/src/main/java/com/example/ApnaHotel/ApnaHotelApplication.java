package com.example.ApnaHotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApnaHotelApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApnaHotelApplication.class, args);
    }
}



