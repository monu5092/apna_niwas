package com.example.ApnaHotel.exception;

public class OurException extends RuntimeException{
    public OurException(String message){
        super(message);
    }
}
